if (localStorage.getItem("adminLoggedIn") !== "true") {
    window.location.href = "/login.html";
}

async function loadDashboard() {

    try {

        const stats = await fetch("/dashboard-stats");
        const data = await stats.json();

        document.getElementById("totalAppointments").innerText =
            data.totalAppointments;

        document.getElementById("totalDoctors").innerText =
            data.totalDoctors;

    } catch (err) {

        console.log(err);

    }

}

async function loadAppointments() {

    try {

        const res = await fetch("/appointments");
        const data = await res.json();

        const table = document.getElementById("appointmentsTable");

        table.innerHTML = "";

        data.appointments.forEach(app => {

            table.innerHTML += `
            <tr>

                <td>${app.id}</td>

                <td>${app.name}</td>

                <td>${app.phone}</td>

                <td>${app.doctor}</td>

                <td>${app.date}</td>

                <td>${app.time}</td>

                <td>

                    <button
                    class="btn btn-warning btn-sm me-2"
                    onclick="editAppointment(${app.id})">

                    Edit

                    </button>

                    <button
                    class="btn btn-danger btn-sm"
                    onclick="deleteAppointment('${app.phone}')">

                    Delete

                    </button>

                </td>

            </tr>
            `;

        });

    } catch (err) {

        console.log(err);

    }

}

function editAppointment(id){

    alert("Edit Appointment ID : " + id);

}

async function deleteAppointment(phone){

    if(!confirm("Delete Appointment?")) return;

    await fetch("/cancel-appointment",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({
            phone
        })

    });

    loadDashboard();
    loadAppointments();

}

document.getElementById("search").addEventListener("keyup",function(){

    const value=this.value.toLowerCase();

    document.querySelectorAll("#appointmentsTable tr").forEach(row=>{

        row.style.display=row.innerText.toLowerCase().includes(value)
        ? ""
        : "none";

    });

});

function logout(){

    localStorage.removeItem("adminLoggedIn");
    localStorage.removeItem("token");

    window.location.href="/login.html";

}

loadDashboard();
loadAppointments();